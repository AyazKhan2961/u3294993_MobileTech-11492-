package com.example.assignment2;

import android.net.Uri;

public class MLKitResult {

    private String firebaseKey;
    private String reader;
    private String result;
    private Uri imageUri;

    public MLKitResult(String firebaseKey, String reader, String result, Uri imageUri) {
        this.firebaseKey = firebaseKey;
        this.reader = reader;
        this.result = result;
        this.imageUri = imageUri;
    }

    public String getFirebaseKey() {
        return firebaseKey;
    }

    public String getReader() {
        return reader;
    }

    public String getResult() {
        return result;
    }

    public Uri getImageUri() {
        return imageUri;
    }
}