package com.example.assignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ListViewActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<MLKitResult> mlKitResults;
    MLKitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list_view);

        listView = findViewById(R.id.listView);
        mlKitResults = new ArrayList<>();

        DatabaseReference dbref =
                FirebaseDatabase.getInstance().getReference("Storage");

        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                mlKitResults.clear();

                for (DataSnapshot itemSnap : snapshot.getChildren()) {

                    String firebaseKey = itemSnap.getKey();

                    String reader =
                            itemSnap.child("reader").getValue(String.class);

                    String result =
                            itemSnap.child("text").getValue(String.class);

                    String imageUriString =
                            itemSnap.child("imageUri").getValue(String.class);

                    Uri uri = null;

                    if (imageUriString != null &&
                            !imageUriString.isEmpty()) {

                        uri = Uri.parse(imageUriString);
                    }

                    mlKitResults.add(
                            new MLKitResult(
                                    firebaseKey,
                                    reader,
                                    result,
                                    uri
                            )
                    );
                }

                adapter = new MLKitAdapter(
                        ListViewActivity.this,
                        R.layout.list_item,
                        mlKitResults
                );

                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError error) { }
        });

        // Open Activity 7 when item clicked
        listView.setOnItemClickListener((parent, view, position, id) -> {

            MLKitResult item = mlKitResults.get(position);

            Intent intent =
                    new Intent(ListViewActivity.this, Activity7.class);

            intent.putExtra("firebaseKey", item.getFirebaseKey());
            intent.putExtra("reader", item.getReader());
            intent.putExtra("result", item.getResult());

            if (item.getImageUri() != null) {
                intent.putExtra(
                        "imageUri",
                        item.getImageUri().toString()
                );
            }

            startActivity(intent);
        });

        Button buttonadd = findViewById(R.id.button_add);
        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListViewActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });


    }
}