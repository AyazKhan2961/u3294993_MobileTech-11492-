package com.example.assignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.FirebaseDatabase;

public class Activity7 extends AppCompatActivity {

    String firebaseKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_7);

        TextView textViewReader =
                findViewById(R.id.textView_Activity7Reader);

        TextView textViewResult =
                findViewById(R.id.textView_Activity7Result);

        ImageView imageView =
                findViewById(R.id.imageView_Activity7);

        Button buttonDelete =
                findViewById(R.id.button_delete);

        Button buttonCancel =
                findViewById(R.id.button_cancel);

        Bundle extras = getIntent().getExtras();

        if (extras != null) {

            firebaseKey = extras.getString("firebaseKey");

            String reader = extras.getString("reader");
            String result = extras.getString("result");
            String imageUriString = extras.getString("imageUri");

            textViewReader.setText(reader);
            textViewResult.setText(result);

            if (imageUriString != null) {
                Uri uri = Uri.parse(imageUriString);
                imageView.setImageURI(uri);
            }
        }

        // DELETE BUTTON
        buttonDelete.setOnClickListener(v -> {

            FirebaseDatabase.getInstance()
                    .getReference("Storage")
                    .child(firebaseKey)
                    .removeValue();

            Toast.makeText(
                    Activity7.this,
                    "Item deleted",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
        });

        // CANCEL BUTTON
        buttonCancel.setOnClickListener(v -> finish());

        // EDIT BUTTON
        Button buttonEdit = findViewById(R.id.button_edit);

        buttonEdit.setOnClickListener(v -> {

            Intent intent = new Intent(Activity7.this, EditorActivity.class);

            intent.putExtra("firebaseKey", firebaseKey); // ⭐ IMPORTANT for UPDATE mode
            intent.putExtra("reader", textViewReader.getText().toString());
            intent.putExtra("mlkitResult", textViewResult.getText().toString());
            intent.putExtra("imageUri", getIntent().getStringExtra("imageUri"));

            startActivity(intent);
        });
    }
}