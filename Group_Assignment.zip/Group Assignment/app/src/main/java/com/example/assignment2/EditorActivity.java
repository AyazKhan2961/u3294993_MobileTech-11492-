package com.example.assignment2;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EditorActivity extends AppCompatActivity {

    private Bitmap bitmap;
    private Uri imageUri;

    private String firebaseKey = null; // ⭐ IMPORTANT (detect edit mode)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editor);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

// Getting data from MlKit activity OR Activity7
        Bundle extras = getIntent().getExtras();

        String mlkitResult = null;
        String reader = null;
        String imageUriString = null;

        if (extras != null) {
            mlkitResult = extras.getString("mlkitResult");
            reader = extras.getString("reader");
            imageUriString = extras.getString("imageUri");

            // ⭐ if coming from Activity7 (EDIT MODE)
            firebaseKey = extras.getString("firebaseKey");
        }

        TextView textViewEditedResult = findViewById(R.id.textView_EditedMLKitResult);
        TextView textViewEditedReader = findViewById(R.id.textView_EditedReader);
        ImageView imageView = findViewById(R.id.imageView);

        textViewEditedResult.setText(mlkitResult);
        textViewEditedReader.setText(reader);

        imageUri = Uri.parse(imageUriString);
        imageView.setImageURI(imageUri);


// convert URI → Bitmap
        try {
            java.io.InputStream inputStream =
                    getContentResolver().openInputStream(imageUri);

            bitmap = android.graphics.BitmapFactory.decodeStream(inputStream);

        } catch (Exception e) {
            e.printStackTrace();
        }



        Button buttonSave = findViewById(R.id.button_save);

        buttonSave.setOnClickListener(v -> saveToFirebaseAndStorage());
    }

    private void saveToFirebaseAndStorage() {

        // 1. Get edited text
        EditText editReader = findViewById(R.id.textView_EditedReader);
        EditText editText = findViewById(R.id.textView_EditedMLKitResult);

        String reader = editReader.getText().toString();
        String text = editText.getText().toString();

        DatabaseReference dbref =
                FirebaseDatabase.getInstance().getReference("Storage");

        // ⭐ CASE 1: EDIT EXISTING ITEM (from Activity7)
        if (firebaseKey != null) {

            DatabaseReference currentItem = dbref.child(firebaseKey);

            currentItem.child("reader").setValue(reader);
            currentItem.child("text").setValue(text);

            Toast.makeText(this, "Updated existing item", Toast.LENGTH_SHORT).show();
        }

        // ⭐ CASE 2: NEW ITEM (from MLKitActivity)
        else {

            String timestamp = String.valueOf(System.currentTimeMillis());

            DatabaseReference currentItem = dbref.child(timestamp);

            currentItem.child("filename").setValue(timestamp + ".jpg");
            currentItem.child("reader").setValue(reader);
            currentItem.child("text").setValue(text);

            Uri savedUri = saveImageToGallery(bitmap, timestamp + ".jpg");

            if (savedUri != null) {
                currentItem.child("imageUri").setValue(savedUri.toString());
            }

            Toast.makeText(this, "Saved new item", Toast.LENGTH_SHORT).show();
        }
    }

    private Uri saveImageToGallery(Bitmap bitmap, String fileName) {

        ContentValues values = new ContentValues();
        values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,
                android.os.Environment.DIRECTORY_PICTURES + "/StorageImages");

        Uri uri = getContentResolver().insert(
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
        );

        try {
            java.io.OutputStream outputStream =
                    getContentResolver().openOutputStream(uri);

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);

            outputStream.flush();
            outputStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return uri;
    }
}