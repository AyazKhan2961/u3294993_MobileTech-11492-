package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
// the onclick event listener that opens activity 6 (lists)
        Button button = findViewById(R.id.button_listAnalysedImages);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListViewActivity.class);
                startActivity(intent);

            }
        });

/*These three onclick listeners open activity 2 (MainActivity) then also transfers the image,
attaches the reader type so it MainActivity only uses selected reader, and the reader name
 */
        ImageView imageView1 = findViewById(R.id.image_barcode);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
                intent.putExtra("image", R.mipmap.barcode_image_foreground); //Reader Image
                intent.putExtra("reader", "barcode"); // Reader Type
                intent.putExtra("message", "Barcode Reader"); //Reader Name

                startActivity(intent);
            }


        });


        ImageView imageView2 = findViewById(R.id.image_content);
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
                intent.putExtra("image", R.mipmap.content_image_foreground);//Reader Image
                intent.putExtra("reader", "content");// Reader Type
                intent.putExtra("message", "Content Reader");//Reader Name

                startActivity(intent);
            }
        });

        ImageView imageView3 = findViewById(R.id.image_text);
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
                intent.putExtra("image", R.mipmap.text_image_foreground);//Reader Image
                intent.putExtra("reader", "text");// Reader Type
                intent.putExtra("message", "Text Reader");//Reader Name


                startActivity(intent);
            }
        });



    }


}