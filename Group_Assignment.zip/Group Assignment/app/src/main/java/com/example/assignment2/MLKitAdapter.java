package com.example.assignment2;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class MLKitAdapter extends ArrayAdapter<MLKitResult> {

    List<MLKitResult> items = new ArrayList<>();

    public MLKitAdapter(@NonNull Context context, int resource, @NonNull List<MLKitResult> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item, parent, false);
        }

        MLKitResult item = items.get(position);

        ImageView icon = convertView.findViewById(R.id.imageView);
        TextView textViewItem = convertView.findViewById(R.id.textViewItem);


        Uri uri = item.getImageUri();

        if (uri != null) {
            icon.setImageURI(uri);
        } else {
            icon.setImageResource(android.R.drawable.ic_menu_report_image);
        }


        textViewItem.setText(
                item.getReader() != null ? item.getReader() : "No reader"
        );

        if (position % 2 == 0) {
            // EVEN ITEMS → WHITE
            convertView.setBackgroundColor(
                    android.graphics.Color.WHITE
            );
        } else {
            // ODD ITEMS → GREY
            convertView.setBackgroundColor(
                    android.graphics.Color.parseColor("#E0E0E0")
            );
        }

        return convertView;
    }
}